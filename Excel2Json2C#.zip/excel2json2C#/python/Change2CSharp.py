
import os,sys
from openpyxl import Workbook,load_workbook
import json
class Change2CSharp(object):
	def ReadLines(self,work_book,fileName):
		
	        ws=work_book.worksheets[0]
	        rows=ws.rows
	        desc_row = next(rows)
	        
	        chinese_row = next(rows)
	        name_row = next(rows)
	        FinalString=""
	        # Constructor=""
	        PropertyDic = {}
	        for (desc,name,chineseName) in zip(desc_row,name_row,chinese_row):
	        	if desc.value==None:
	        		continue
	        	NoteText = "\t/// <summary>\n\t/// %s \n\t/// <summary>\n" % chineseName.value
	        	PropertyName = str(name.value).lower()
	        	CSharpText = "\tprivate %s %s;\n" % (desc.value,PropertyName)
	        	CSharpText2 = "\tpublic %s %s\n\t{\n\t\tset { %s = value; }\n\t\tget { return %s; }\n\t}\n" % (desc.value,PropertyName.capitalize(),PropertyName,PropertyName)
	        	FinalString = FinalString+(NoteText + CSharpText + CSharpText2)
	        	PropertyDic[PropertyName.capitalize()] = desc.value
	
	        # ParaList = ""
	        # InConstructor = ""
	        # for x in PropertyDic:
	        # 	ParaList = ParaList + PropertyDic[x]+" "+x+" , "
	        # 	InConstructor = InConstructor + "\t\tthis.%s = %s;\n" % (x,x)
	        # ParaList = ParaList[0:len(ParaList)-3]
	
	        CSName = str(fileName).split('\\')[-1].split('.')[0]
	        # Constructor = "\tpublic %s(%s)\n\t{\n%s\n\t}\n" % (CSName,ParaList,InConstructor)
	        CScriptText = "using System.Collections.Generic;\n[System.Serializable]\npublic class %s\n{\n%s}" % (CSName,FinalString)
	        self.CreateFileToPC(CSName,CScriptText)         
	def CreateFileToPC(self,FileName,text):
		fp=open(os.getcwd()+"\\"+FileName+".cs","w")
		try:
			fp.write(text)
		finally:
			fp.close()

