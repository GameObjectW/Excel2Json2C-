﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {

	// Use this for initialization
	void Start () {
		InitGameDataFromJson data = new InitGameDataFromJson();
	    GameData gameData = data.GetData();
	    foreach (Enemypropertytable enemypropertytable in gameData.Data)
	    {
            Debug.Log(enemypropertytable.Name);
	    }
	}
	
}
