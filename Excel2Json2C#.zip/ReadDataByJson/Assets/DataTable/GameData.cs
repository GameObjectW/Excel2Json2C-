﻿using System;
using System.Collections.Generic;

[Serializable]
public class GameData
{
    public List<Enemypropertytable> Data { get; set; }
}
