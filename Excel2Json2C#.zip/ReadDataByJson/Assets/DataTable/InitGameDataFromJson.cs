﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using UnityEngine;
using Newtonsoft.Json;


public class InitGameDataFromJson
{
    public GameData GetData()
    {
        string jsonString = File.ReadAllText(Application.streamingAssetsPath + "/Enemypropertytable.xlsx.json", Encoding.UTF8);
        GameData data = JsonConvert.DeserializeObject<GameData>(jsonString);
        return data;
    }
}


