using System.Collections.Generic;
[System.Serializable]
public class Enemypropertytable
{
	/// <summary>
	/// id 
	/// <summary>
	private int id;
	public int Id
	{
		set { id = value; }
		get { return id; }
	}
	/// <summary>
	/// ���� 
	/// <summary>
	private string name;
	public string Name
	{
		set { name = value; }
		get { return name; }
	}
	/// <summary>
	/// Ѫ�� 
	/// <summary>
	private int hp;
	public int Hp
	{
		set { hp = value; }
		get { return hp; }
	}
	/// <summary>
	/// �˺���Χ 
	/// <summary>
	private float scopedamage;
	public float Scopedamage
	{
		set { scopedamage = value; }
		get { return scopedamage; }
	}
	/// <summary>
	/// ������Ч 
	/// <summary>
	private List<int> deadaudio;
	public List<int> Deadaudio
	{
		set { deadaudio = value; }
		get { return deadaudio; }
	}
	
}